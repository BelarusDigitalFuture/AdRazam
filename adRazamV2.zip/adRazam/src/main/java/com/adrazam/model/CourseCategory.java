package com.adrazam.model;

public enum  CourseCategory {
    theoreticalSciences,
    naturalSciences,
    technicalSciences,
    socialSciences,
    economicalSciences,
    design,
    beginnerProgramming,
    intermediateProgramming,
    advancedProgramming,
    marketing,
    digitalMarketing
}
