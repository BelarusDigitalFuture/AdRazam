package com.adrazam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdrazamApplication {
    public static void main(String[] args) {
        SpringApplication.run(AdrazamApplication.class, args);
    }
}
