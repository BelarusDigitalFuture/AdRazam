package com.adrazam.controller;

import com.adrazam.model.CourseType;
import com.adrazam.model.User;
import com.adrazam.model.UserInfo;
import com.adrazam.repository.CourseTypeRepository;
import com.adrazam.repository.UserInfoRepository;
import com.adrazam.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.List;

@Controller
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private UserInfoRepository userInfoRepository;

    @Autowired
    private CourseTypeRepository courseTypeRepository;

    @PostMapping("/newAccount")
    public String newUserPost(@ModelAttribute("login") String login,
                              @ModelAttribute("password") String password,
                              @ModelAttribute("userFile") MultipartFile userFile,
                              @RequestParam("radioName") String student) {
        User user = userService.createUser(login, password, student);
        try {
            if (userFile != null) {
                byte[] bytes = userFile.getBytes();
                UserInfo userInfo = userInfoRepository.findByUser(user);
                userInfo.setConfirmation(user.getId() + ".docx");
                userService.save(user);
                String name = user.getId() + ".docx";
                BufferedOutputStream stream = new BufferedOutputStream(
                        new FileOutputStream(new File("src/main/resources/static/image/user/" + name)));
                stream.write(bytes);
                stream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "login";
    }

    @GetMapping("/userProfile")
    public String userProfile(Model model, Principal principal) {
        User user = userService.findByLogin(principal.getName());
        UserInfo userInfo = userInfoRepository.findByUser(user);
        List<CourseType> courseTypeList = courseTypeRepository.findAll();
        if (userInfo.getImage() != null) {
            model.addAttribute("imageNotNull", true);
        }
        model.addAttribute("courseTypeList",courseTypeList);
        model.addAttribute("userInfo", userInfo);
        model.addAttribute("count", user.getCourses().size());
        return "userProfile";
    }

    @GetMapping("/mentorProfile")
    public String mentorProfile(Model model, Principal principal) {
        User user = userService.findByLogin(principal.getName());
        UserInfo userInfo = userInfoRepository.findByUser(user);
        if (userInfo.getImage() != null) {
            model.addAttribute("imageNotNull", true);
        }
        model.addAttribute("userInfo", userInfo);
        model.addAttribute("count", user.getCourses().size());
        return "mentorProfile";
    }

    @GetMapping("/editProfile")
    public String editProfile(Model model, Principal principal) {
        User user = userService.findByLogin(principal.getName());
        model.addAttribute("userInfo", userInfoRepository.findByUser(user));
        return "editProfile";
    }

    @PostMapping("/editProfile")
    public String editProfilePost(@ModelAttribute("userInfo") UserInfo userInfo,
                                  @ModelAttribute("imageProfile") MultipartFile imageProfile,
                                  Principal principal) {
        User user = userService.findByLogin(principal.getName());
        String name = user.getId()+".png";
        if (!imageProfile.isEmpty()) {
            try {
                byte[] bytes = imageProfile.getBytes();
                try {
                    Files.delete(Paths.get("src/main/resources/static/image/profile/" + name));
                }
                catch (NoSuchFileException exception){
                    System.out.println(exception.getMessage());
                }
                BufferedOutputStream stream = new BufferedOutputStream(
                        new FileOutputStream(new File("src/main/resources/static/image/profile/" + name)));
                stream.write(bytes);
                stream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        UserInfo infoDB = userInfoRepository.findByUser(user);
        infoDB.update(userInfo);
        infoDB.setImage(name);
        userInfoRepository.save(infoDB);
        return "userProfile";
    }
}
