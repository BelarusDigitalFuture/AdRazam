package com.adrazam.controller;

import com.adrazam.model.Course;
import com.adrazam.model.CourseType;
import com.adrazam.model.User;
import com.adrazam.repository.CourseRepository;
import com.adrazam.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
public class CourseController {
    @Autowired
    private UserService userService;

    @Autowired
    private CourseRepository courseRepository;

    @PostMapping("/coursePage")
    public String coursePage(@ModelAttribute("category") Integer category, Model model) {
        List<User> userList = userService.findByRoleName("ROLE_MENTOR");
        List<Course> courseList = courseRepository.findByCourseType_Id(category);
        List<User> finalUsers = new ArrayList<>();
        for (User user : userList) {
            if (UserService.checkUser(user, courseList)) {
                finalUsers.add(user);
            }
        }
        if (finalUsers.size() == 0) {
            model.addAttribute("emptyList", true);
        } else {
            model.addAttribute("userList", finalUsers);
        }
        return "coursePage";
    }

    @PostMapping("/addCourse")
    public String addCourse(@ModelAttribute("course") Course course,
                            @ModelAttribute("courseType") CourseType courseType,
                            Principal principal) {
        User user = userService.findByLogin(principal.getName());
        course.setUsers(List.of(user));
        course.setCourseType(courseType);
        courseRepository.save(course);
        return "mentorProfile";
    }
}
