package com.adrazam.repository;

import com.adrazam.model.Role;
import com.adrazam.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Integer> {
    Role findByUser(User user);
}
