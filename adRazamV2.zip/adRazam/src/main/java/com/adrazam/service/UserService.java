package com.adrazam.service;

import com.adrazam.model.Course;
import com.adrazam.model.Role;
import com.adrazam.model.User;
import com.adrazam.model.UserInfo;
import com.adrazam.repository.RoleRepository;
import com.adrazam.repository.UserInfoRepository;
import com.adrazam.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements UserDetailsService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserInfoRepository userInfoRepository;

    @Autowired
    private RoleRepository roleRepository;

    public User createUser (String login, String password, String student) {
        User user = new User();
        user.setLogin(login);
        user.setPassword(BCrypt.hashpw(password, BCrypt.gensalt(12)));
        Role role = new Role();
        if(student.equals("student")) {
            role.setName("ROLE_STUDENT");
        }
        else {
            role.setName("ROLE_MENTOR");
        }
        role.setUser(user);
        roleRepository.save(role);
        UserInfo userInfo = new UserInfo();
        userInfo.setUser(user);
        userInfoRepository.save(userInfo);
        save(user);
        return user;
    }

    public void save(User user) {
        userRepository.save(user);
    }

    @Override
    public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException {
        User user = userRepository.findByLogin(login).orElseThrow(() ->
                new UsernameNotFoundException("User doesn't exist"));
        return User.fromUser(user);
    }

    public User findByLogin(String name) {
        return userRepository.findByLogin(name).orElse(null);
    }

    public User findByUserInfo(UserInfo userInfo) {
        return userRepository.findByUserInfo(userInfo);
    }

    public List<User> findByRoleName(String role_mentor) {
        return userRepository.findByRole_Name(role_mentor);
    }

    public static boolean checkUser(User user, List<Course> courses){
        List<Course> userCourses = user.getCourses();
        for (Course userCourse : userCourses){
            for (Course course : courses){
                if (userCourse.getId() == course.getId())
                    return true;
            }
        }
        return false;
    }
}
