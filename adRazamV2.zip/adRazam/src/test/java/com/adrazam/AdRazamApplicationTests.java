package com.adrazam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdRazamApplicationTests {

	@Test
	void contextLoads() {
	}

}
